<?php
class Helper{

  public static function alert(string $msg){
    echo "<script>alert('$msg');</script>";
  }
  
}
